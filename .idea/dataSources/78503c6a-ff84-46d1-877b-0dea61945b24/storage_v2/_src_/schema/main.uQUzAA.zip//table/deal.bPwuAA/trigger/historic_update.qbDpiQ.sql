CREATE TRIGGER historic_update
    AFTER insert
    ON deal
BEGIN
    INSERT INTO deal_historic(id, is_rent, date_start_rent, duration_days_rent, id_customer, id_car)
    VALUES (new.id, new.is_rent, new.date_start_rent, new.duration_days_rent, new.id_customer, new.id_car);
END;

